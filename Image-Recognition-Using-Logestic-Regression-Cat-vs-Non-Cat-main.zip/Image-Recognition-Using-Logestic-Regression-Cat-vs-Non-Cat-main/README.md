# Image-Recognition-Using-Logestic-Regression-Cat-vs-Non-Cat
A Simple Image Recognition Algorithm using Logestic Regression implemented using Cat vs Non-Cat dataset

# Language Used:-
- Python

# Algorithm Used:-
- Logestic Regression

Basic Machine Learning Project.
